<?php
$SecretKey = ""; // Add your secret key here. Remember to change this to your live secret key in production
$PublicKey = ""; // Add your public key here. Remember to change this to your live public key in production
